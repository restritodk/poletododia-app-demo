package io.flutter.plugins.firebase.messaging.sqlite;

public enum NotificationType {
    calendar, comments, class_post, push_custom, unknown
}
