package io.flutter.plugins.firebase.messaging.sqlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

public class NotificationDB extends SQLiteOpenHelper {

    private static final String _id = "id";
    private static final String _table = "notifications";
    private static final String _notificationID = "notification_id";
    private static final String _title = "title";
    private static final String _body = "body";
    private static final String _image = "image";
    private static final String _link = "link";
    private static final String _itemID = "item_id";
    private static final String _read = "read";
    private static final String _notificationType = "notification_type";
    private static final String _createdAt = "created_at";

    private final String[] dataValues = new String[]{_id, _notificationID, _title, _body, _image, _link, _itemID, _notificationType, _createdAt};
    private Context context;

    public NotificationDB(Context mContext){
        super(mContext, "NotificationsApp.db", null, 3);
        this.context = mContext;
    }


    public void addNotification(NotificationModel notificationModel){
        try{
            SQLiteDatabase sqLiteDatabase = getReadableDatabase();
            System.out.println("sqLiteDatabase "+sqLiteDatabase.getPath());
            String[] selectionArgs = {notificationModel.notificationID};
            String selection = _notificationID + "=?";
            try (Cursor cursor = sqLiteDatabase.query(_table, null, selection, selectionArgs, null, null, null)) {

                if (cursor.getCount() == 0) {
                    ContentValues values = new ContentValues();
                    values.put(_notificationID, notificationModel.notificationID);
                    values.put(_title, notificationModel.title);
                    values.put(_body, notificationModel.body);
                    values.put(_link, notificationModel.link);
                    values.put(_image, notificationModel.image);
                    values.put(_itemID, notificationModel.itemID);
                    values.put(_read, notificationModel.read ? "true" : "false");
                    values.put(_notificationType, notificationModel.notificationType.name());
                    Date currentDate = new Date();

                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSSSS");
                    String formattedDate = dateFormat.format(currentDate);
                    values.put(_createdAt, formattedDate);


                    sqLiteDatabase.insert(_table, null, values);
                }
            }
            sqLiteDatabase.close();
        }catch (Exception exception){
            System.out.println("Error ao salvar notificacao: "+exception.getMessage());
        }
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE " +_table+ "(" + _id + " INTEGER PRIMARY KEY AUTOINCREMENT, " +_notificationID+" TEXT, "+_title+" TEXT, "+_body+" TEXT, "+_image+" TEXT, "+_link+" TEXT, "+_itemID+" TEXT, "+_notificationType+" TEXT, "+_read+" TEXT, "+_createdAt+" TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        if(i == 2 && i1 == 3){
            sqLiteDatabase.execSQL("ALTER TABLE " + _table + " ADD COLUMN " + _notificationID + " TEXT;");
        }
    }

}